package q3_busqueda_subtexto;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class BusquedaSubtexto {

    public static class SearchMapper extends Mapper<LongWritable, Text, Text, NullWritable> {
        private String searchTerm;

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            searchTerm = context.getConfiguration().get("searchTerm").toUpperCase();
        }

        @Override
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            if (key.get() == 0) return;

            String[] fields = value.toString().split(";");
            if (fields.length > 19) {
                String diagnostico = fields[13].toUpperCase();
                String procedimiento1 = fields[19].toUpperCase();

                if (diagnostico.contains(searchTerm) || procedimiento1.contains(searchTerm)) {
                    context.write(value, NullWritable.get());
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.set("searchTerm", args[2]);

        Job job = Job.getInstance(conf, "Busqueda de Subtexto");
        job.setJarByClass(BusquedaSubtexto.class);
        job.setMapperClass(SearchMapper.class);
        job.setNumReduceTasks(0);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(NullWritable.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}