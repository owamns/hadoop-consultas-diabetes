# Hadoop Patologías Relacionadas con Diabetes

Este proyecto contiene varios jobs de MapReduce y pasos de procesamiento en Java para analizar un conjunto de datos de pacientes con diabetes. Los ejecutables se generan con Maven; cada clase principal produce su propio JAR.

## Formato del dataset

El CSV de entrada utiliza `;` como separador y tiene las siguientes columnas:

```
FECHA_CORTE;DEPARTAMENTO;PROVINCIA;DISTRITO;UBIGEO;RED;IPRESS;ID_PACIENTE;EDAD_PACIENTE;SEXO_PACIENTE;EDAD_MEDICO;ID_MEDICO;COD_DIAG;DIAGNOSTICO;AREA_HOSPITALARIA;SERVICIO_HOSPITALARIO;ACTIVIDAD_HOSPITALARIA;FECHA_MUESTRA;FEC_RESULTADO_1;PROCEDIMIENTO_1;RESULTADO_1;UNIDADES_1;FEC_RESULTADO_2;PROCEDIMIENTO_2;RESULTADO_2;UNIDADES_2
``` 

### Ejemplo de registros

```
20240531;UCAYALI;CORONEL PORTILLO;MANANTAY;250107;RED ASISTENCIAL UCAYALI;CAP I MANANTAY;eJwzNDAwtDC0NDMxNzAyMzWxMAQAHqoDcA==;51;MASCULINO;26;eJwzNjA2MzE2NLY0NzO2NDWyMAQAHxMDeg==;E11.9;DIABETES MELLITUS TIPO 2, SIN MENCION DE COMPLICACION;CONSULTA EXTERNA;MEDICINA GENERAL;ATENCION  MEDICA AMBULATORIA;20200102;20200111;DOSAJE DE COLESTEROL TOTAL EN SANGRE COMPLETA O SUERO;217.0;mg/dL;20200111;DOSAJE DE GLUCOSA EN SANGRE, CUANTITATIVO (EXCEPTO CINTA REACTIVA);258.0;mg/dL
20240531;UCAYALI;CORONEL PORTILLO;YARINACOCHA;250105;RED ASISTENCIAL UCAYALI;P.M. ALAMEDA;eJwzNDAwMjAxNTUxsbQ0NTAzMgUAHnQDbg==;48;FEMENINO;26;eJwzsjS1NDI2MjE2NTaxNLEwsAQAH4YDgg==;E13.9;DIABETES MELLITUS ESPECIFICADA, SIN MENCION DE COMPLICACION;CONSULTA EXTERNA;MEDICINA GENERAL;ATENCION  MEDICA AMBULATORIA;20200102;20200111;DOSAJE DE COLESTEROL TOTAL EN SANGRE COMPLETA O SUERO;192.0;mg/dL;20200111;DOSAJE DE GLUCOSA EN SANGRE, CUANTITATIVO (EXCEPTO CINTA REACTIVA);171.0;mg/dL
```

## Jobs y clases principales

### q1_consultas_multiples_campos
- **EdadPromedioPorDiagnostico**: calcula la edad promedio de pacientes agrupados por código o descripción de diagnóstico (`COD_DIAG`, `DIAGNOSTICO`).
- **PacientesPorDeptoSexo**: cuenta la cantidad de pacientes por departamento (`DEPARTAMENTO`) y sexo (`SEXO_PACIENTE`).
- **ProcedimientosPorAreaServicio**: contabiliza la frecuencia de cada procedimiento (`PROCEDIMIENTO_1`/`PROCEDIMIENTO_2`) según área hospitalaria (`AREA_HOSPITALARIA`) y servicio (`SERVICIO_HOSPITALARIO`).

### q2_estadisticas_descriptivas
- **EstadisticasColesterol**: calcula estadísticas descriptivas (mínimo, máximo, media y desviación estándar) de los valores de colesterol (`RESULTADO_1` cuando `PROCEDIMIENTO_1` corresponde a colesterol).

### q3_busqueda_subtexto
- **BusquedaSubtexto**: filtra registros donde la descripción de diagnóstico (`DIAGNOSTICO`) contiene un subtexto proporcionado como parámetro.

### q4_busqueda_rango_fechas
- **BusquedaPorFechas**: extrae los registros cuya fecha de muestra (`FECHA_MUESTRA`) está dentro de un rango de fechas especificado.

### q5_valores_extremos
- **MinMaxColesterolPorDepto**: identifica el valor mínimo y máximo de colesterol (`RESULTADO_1`) por departamento (`DEPARTAMENTO`).

### q6_jobs_encadenados
- **GlucosaSobrePromedioNacional**: primer job que calcula la media nacional de glucosa (`RESULTADO_2` para glucosa) y marca los registros por encima de la media.
- **NormalizacionMinMaxColesterol**: segundo job que normaliza valores de colesterol por departamento usando normalización Min-Max.

### q7_modelos_clasificacion
- **ClasificacionRiesgoCardiovascular**: entrena o aplica un modelo simple de clasificación para predecir riesgo cardiovascular usando características como edad, sexo, colesterol y glucosa.
- **PrediccionReingresoSimple**: modelo básico para predecir la probabilidad de reingreso del paciente, considerando fecha de corte, diagnósticos y resultados de laboratorio.

## Compilación y ejecución

Compila y genera los 11 JARs con:
```
mvn clean package
```

Se generarán archivos en `target/` con el sufijo del job. Por ejemplo:
```
target/hadoop-patologias-relacionadas-diabetes-1.0-SNAPSHOT-BusquedaSubtexto.jar
```

Ejecuta cada job con:
```
java -jar target/...SNAPSHOT-<JobName>.jar <inputDir> <outputDir>
```

---

*Este README describe brevemente la finalidad de cada clase principal y cómo procesan el dataset de pacientes con diabetes.*

